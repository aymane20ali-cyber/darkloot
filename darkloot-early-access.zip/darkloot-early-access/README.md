# DarkLoot — Early Access Website

An original dark-fantasy pixel-art RPG landing page and early-access prototype built with React, TypeScript, Vite, and custom CSS. It is designed to deploy to Cloudflare Pages.

## Requirements

- Node.js 20+
- npm 10+

## Run locally

```bash
npm install
npm run dev
```

Open the local URL printed by Vite.

## Production build

```bash
npm run build
npm run preview
```

Vite outputs static files to `dist/`.

## What's functional

- Responsive navigation and section links.
- Hero, game-mechanics, sample hero roster, dungeon schematic, roadmap, FAQ, community, and legal/disclaimer sections.
- Registration form validation and loading/success/error UI.
- A demo registration ID generated client-side.
- Demo mission checklist and referral-link copy interaction.
- Solana wallet adapter UI configured for Devnet with Phantom and Solflare adapters. Wallet connection is optional. The app does not sign messages or submit transactions.
- Reduced-motion support and keyboard focus styles.

## Demo-only / not production-connected

- Registration is simulated in the browser. It waits briefly and generates a demo ID, but does not save to a database or send email.
- Referral code and mission completion are demo interactions. Counts and points are not verified and have no real-world value.
- Whitelist status is currently a demo `Registered` state only. Backend-driven statuses (`Registered`, `Pending Review`, `Approved`, `Waitlisted`) should be implemented through the API described below before launch.
- Solana is set to Devnet. There are no payments, token transfers, eligibility checks, or arbitrary message signatures.
- Payment adapter is an interface only; real payments are disabled.
- External community links are placeholders until official project URLs exist.
- Hero names, rarity, and combat attributes are sample presentation data, not final game data.

## Architecture

- `src/App.tsx` — page composition and client-side UI state.
- `src/styles.css` — responsive design system and original CSS pixel-art illustrations.
- `src/data/game.ts` — sample heroes, mechanics, missions, and FAQ content.
- `src/lib/registration.ts` — demo registration service. Replace with a request to a Cloudflare Worker.
- `src/lib/WalletProvider.tsx` — maintained Solana Wallet Adapter providers, Devnet configuration.
- `src/lib/payment.ts` — documented future payment interface; deliberately disabled.

## Recommended production registration API

Create Cloudflare Worker endpoints such as:

- `POST /api/registrations` — validate input server-side, normalize username/email, apply rate limits, check duplicate email and referral self-referral, then create a D1 record.
- `GET /api/registrations/:id` — return the caller-authorized registration status and safe metadata.
- `GET /api/referrals/me` — return referral count/history from verified database records.
- `POST /api/missions/:missionId/claim` — only for missions with a verifiable server-side proof.

Suggested D1 tables: `registrations`, `referrals`, `mission_claims`, `audit_events`. Use unique constraints for normalized email/username as appropriate, parameterized SQL, Turnstile or equivalent bot mitigation, request throttling, strict input validation, CORS allowlists, and minimal retention. Never store wallet secrets or seed phrases. Do not trust counts, status, payment claims, or referral claims supplied by the browser.

Before collecting real personal data, publish actual Terms of Service and a privacy notice, decide retention/deletion procedures, and connect an email provider from the Worker (never from browser code).

## Solana and future payments

The wallet adapter only establishes an optional wallet connection. A connected wallet is not proof of payment, whitelist approval, or eligibility. For any future paid registration, show the fee, purpose, live SOL/USD quote source, verified recipient, and network fee before asking the user to approve. Verify transaction confirmation server-side against trusted Solana RPC data, enforce idempotency/duplicate protection, and never trust a frontend success callback. The payment module is intentionally non-operational in this prototype.
