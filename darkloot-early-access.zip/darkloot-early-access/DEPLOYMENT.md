# Deploy DarkLoot to Cloudflare Pages

## Option A — Git integration (recommended)

1. Push this project to a Git repository.
2. In the Cloudflare dashboard, open **Workers & Pages → Create → Pages → Connect to Git**.
3. Select the repository.
4. Configure the build:
   - **Framework preset:** Vite (or None)
   - **Build command:** `npm run build`
   - **Build output directory:** `dist`
   - **Node version:** 20 or newer
5. Deploy. Every push to the configured production branch can trigger a new build.

## Option B — Wrangler CLI

Install dependencies and build first:

```bash
npm install
npm run build
npx wrangler pages deploy dist --project-name darkloot-early-access
```

Follow the Wrangler prompts to create or select a Pages project. Do not put provider secrets in Vite environment variables prefixed with `VITE_`; those values are bundled into client code.

## Routing

The current site is a single-page landing page with in-page anchors, so no rewrite rules are needed. If you add client-side routes later, configure Pages fallback behavior and test deep links.

## Before public launch

- Connect a Cloudflare Worker API and D1 database for registration, referral verification, and status changes.
- Replace demo registration code with server-confirmed API responses. Do not display “saved” until the server confirms the write.
- Publish real privacy and terms pages; the current footer copy is a prototype disclaimer, not legal advice.
- Add official Discord/social links, project-owned artwork, analytics only with an appropriate privacy plan, and error monitoring.
- Configure bot protection, server-side validation, rate limiting, abuse controls, and email confirmation.
- Keep real payment transfers disabled until recipient verification, quotes, transaction summaries, network-fee disclosure, server-side transaction verification, idempotency, and recovery flows are implemented and audited.
- If using wallet features in production, choose and document the intended Solana cluster. This prototype uses Devnet and does not sign or send transactions.
- Test mobile layout, keyboard navigation, screen readers, reduced-motion preferences, form errors, and wallet rejection/missing-wallet cases.
