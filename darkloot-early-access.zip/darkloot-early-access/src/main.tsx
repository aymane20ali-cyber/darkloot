import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { WalletProvider } from './lib/WalletProvider';
import App from './App';
import './styles.css';
import '@solana/wallet-adapter-react-ui/styles.css';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode><BrowserRouter><WalletProvider><App /></WalletProvider></BrowserRouter></React.StrictMode>
);
