export const heroes = [
  { name: 'Kael Ashguard', role: 'Warrior', rarity: 'Rare', color: 'ember', icon: '⚔', description: 'A last-line sentinel who turns pressure into power.', stats: [['ATK','82'],['VIT','94'],['SPD','42']] },
  { name: 'Sylvi Thorn', role: 'Archer', rarity: 'Epic', color: 'moss', icon: '➶', description: 'A silent pathfinder who never wastes an arrow.', stats: [['ATK','78'],['VIT','55'],['SPD','91']] },
  { name: 'Nyx Veilborn', role: 'Mage', rarity: 'Legendary', color: 'violet', icon: '✦', description: 'Channels the old light sealed beneath the crypt.', stats: [['ATK','97'],['VIT','48'],['SPD','73']] },
  { name: 'Vex Nocturne', role: 'Assassin', rarity: 'Mythic', color: 'rose', icon: '⌁', description: 'A blink in the dark. A blade before the warning.', stats: [['ATK','91'],['VIT','51'],['SPD','99']] },
  { name: 'Brum Stonefist', role: 'Brawler', rarity: 'Common', color: 'gold', icon: '✊', description: 'A stubborn pit-fighter with a heart of iron.', stats: [['ATK','70'],['VIT','88'],['SPD','58']] },
];
export const mechanics = [
  { n:'01', title:'Collect heroes', desc:'Build a roster of unlikely legends, each with a role to play.', icon:'♟' },
  { n:'02', title:'Explore dungeons', desc:'Descend room by room into forgotten halls and sealed vaults.', icon:'▦' },
  { n:'03', title:'Fight monsters', desc:'Read enemy patterns, spend energy wisely, and survive the encounter.', icon:'⚔' },
  { n:'04', title:'Recover energy', desc:'Return to camp, regroup, and choose when your next run begins.', icon:'♨' },
  { n:'05', title:'Discover loot', desc:'Uncover equipment, skins, relics, and stories hidden in the dark.', icon:'◇' },
  { n:'06', title:'Upgrade your team', desc:'Shape your strategy with progression that rewards experimentation.', icon:'↗' },
];
export const missions = [
  { id:'discord', title:'Enter the community', detail:'Join the official Discord', points:100, icon:'◉' },
  { id:'announcements', title:'Keep watch', detail:'Follow project announcements', points:50, icon:'⌁' },
  { id:'heroes', title:'Meet the legends', detail:'Explore the hero roster', points:25, icon:'♟' },
  { id:'lore', title:'Read the old tales', detail:'Discover the world of DarkLoot', points:25, icon:'▤' },
];
export const faq = [
  ['What is DarkLoot?','DarkLoot is an original dark fantasy RPG concept built around pixel-art dungeon exploration, collectible heroes, tactical encounters, and loot-driven progression.'],
  ['What is Early Access?','It is an interest list for early news, prototype access opportunities, and community playtests. Registration is free in this prototype.'],
  ['How does the whitelist work?','Registrations may be reviewed as the project develops. Your status will be shown as Registered, Pending Review, Approved, or Waitlisted when a backend is connected.'],
  ['Is a Solana wallet required?','No. Wallet connection is optional and is not required to join the early access interest list.'],
  ['Are tokens guaranteed?','No. Registration does not guarantee tokens, an airdrop, an allocation, or any financial return.'],
  ['How is personal information handled?','This demo does not send or persist registration data. A production launch should connect a secure backend and publish a full privacy notice.'],
  ['When will the game become playable?','No release date is being promised yet. Follow official announcements for verified milestones and playtest news.'],
];
