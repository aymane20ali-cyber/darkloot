/** Future payment adapter contract. Real transfers are deliberately disabled in the prototype. */
export type PaymentQuote = { amountSol: number; amountUsd: number; networkFeeSol: number; recipient: string; expiresAt: string };
export type PaymentResult = { signature: string; confirmed: boolean; slot?: number };
export interface RegistrationPaymentProvider {
  createQuote(input: { registrationId: string; walletAddress: string }): Promise<PaymentQuote>;
  submitPayment(input: { quote: PaymentQuote; walletAddress: string }): Promise<PaymentResult>;
  verifyPayment(input: { signature: string; registrationId: string }): Promise<PaymentResult>;
}
export const paymentMode = 'disabled' as const;
export function assertPaymentsDisabled(): never {
  throw new Error('Real payments are disabled in the DarkLoot prototype.');
}
