import { useMemo, type ReactNode } from 'react';
import { ConnectionProvider, WalletProvider as AdapterWalletProvider } from '@solana/wallet-adapter-react';
import { WalletModalProvider } from '@solana/wallet-adapter-react-ui';
import { PhantomWalletAdapter, SolflareWalletAdapter } from '@solana/wallet-adapter-wallets';

// Devnet is intentionally used for the prototype. No payments or signing are performed.
export function WalletProvider({ children }: { children: ReactNode }) {
  const endpoint = 'https://api.devnet.solana.com';
  const wallets = useMemo(() => [new PhantomWalletAdapter(), new SolflareWalletAdapter()], []);
  return <ConnectionProvider endpoint={endpoint}><AdapterWalletProvider wallets={wallets} autoConnect={false}><WalletModalProvider>{children}</WalletModalProvider></AdapterWalletProvider></ConnectionProvider>;
}
