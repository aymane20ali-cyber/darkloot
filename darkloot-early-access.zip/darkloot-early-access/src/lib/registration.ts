export type RegistrationInput = { username: string; email: string; wallet?: string; referral?: string; acceptedTerms: boolean };
export type RegistrationRecord = RegistrationInput & { id: string; status: 'Registered'; createdAt: string };

// Demo-only: intentionally does not persist or transmit personal information.
export async function registerDemo(input: RegistrationInput): Promise<RegistrationRecord> {
  await new Promise((resolve) => setTimeout(resolve, 700));
  return { ...input, id: `DL-${crypto.randomUUID().slice(0, 8).toUpperCase()}`, status: 'Registered', createdAt: new Date().toISOString() };
}
